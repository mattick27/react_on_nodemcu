var http = require('http')
var app = require('express')();
var server = http.createServer(app)
var xml = require('xml');

var home = 
    {    
        'Temp' : {
            stat_C : 0, // C
            stat_F : 0 // F
        },
        'Humidity' : {
            button : 0, 
            status : 0, // %
        },
        'Curtain' :{
            status : 0, //lumen
            button : 0,
            mode : 0 ,
        },
        'Bin' : {
            status : 0,
        },
        'Ledstair' : {
            count : 0, //person
        },
    }

var home_xml =  {
    'gg' : 'wtf',
}

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  res.header("Content-type" , 'application/json')
  next();
});

app.get('/', function (req, res) {
    res.json(home)
})
app.get('/text', function (req, res) {
    res.set('Content-Type', 'text/xml');
    res.send(xml(home_xml));
})
//////////////////////////////////
/// TOP IS RETURN JSON ///////////
//////////////////////////////////
app.get('/hum/on', function (req, res) {
    home.Humidity.button = 1
    console.log('Humbutton is ' + home.Humidity.button)
})

app.get('/hum/on2', function (req, res) {
    home.Humidity.button = 1
    console.log('Humbutton is ' + home.Humidity.button)
})

app.get('/hum/off', function (req, res) {
    home.Humidity.button = 0
    console.log('Humbutton is ' + home.Humidity.button)
})

app.get('/hum/off2', function (req, res) {
    home.Humidity.button = 0
    console.log('Humbutton is ' + home.Humidity.button)
})
//////////////////////////////////
/// TOP IS HUMIDITY BUTTON ///////
//////////////////////////////////
app.get('/cur/on', function (req, res) {
    home.Curtain.button = 1
    console.log('Curtain is ' + home.Curtain.button)
})

app.get('/cur/off', function (req, res) {
    home.Curtain.button = 0
    console.log('Curtain is ' + home.Curtain.button)
})
//////////////////////////////////
/// TOP IS CURTAIN BUTTON ////////
//////////////////////////////////

server.listen(8000,'172.20.10.3',function(){
})
var os = require( 'os' );

var networkInterfaces = os.networkInterfaces( );

console.log( networkInterfaces.en0[1].address );
